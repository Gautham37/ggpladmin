<div class='btn-group btn-group-sm'>

  @can('products.stock')
  <a data-placement="bottom" title="{{trans('lang.product_stock')}}" onclick="adjustStock(this);" data-id="{{$id}}" data-toggle="modal" data-target="#productStockModal" class='btn btn-sm btn-primary btn-link'>
    {!! trans('lang.add_wastage') !!}
  </a>
  @endcan
  
</div>
