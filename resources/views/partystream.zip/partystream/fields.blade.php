@if($customFields)
<h5 class="col-12 pb-4">{!! trans('lang.main_fields') !!}</h5>
@endif
<div style="flex: 50%;max-width: 50%;padding: 0 4px;" class="column">

  <input type="hidden" id="customerlevel_count" value="{{$customerlevel_count+1}}">

<!-- Category Id Field -->
<div class="form-group row ">
    {!! Form::label('customerlevel_id', trans("lang.customerlevel_id"),['class' => 'col-3 control-label text-right']) !!}
    <div class="col-9">
        {!! Form::select('customerlevel_id', $category, null, ['class' => 'form-control customerlevel_id']) !!}
        <div class="form-text text-muted">{{ trans("lang.customerlevel_id_help") }}</div>
    </div>
</div>

<!--Category Name Field -->
    <div class="form-group row customerlevel_name" style="display: none;">
        {!! Form::label('customerlevel_name', trans("lang.customerlevel_name"), ['class' => 'col-3 control-label text-right']) !!}
        <div class="col-9">
            {!! Form::text('customerlevel_name', null,  ['class' => 'form-control','placeholder'=>  trans("lang.customerlevel_name_placeholder")]) !!}
            <div class="form-text text-muted">
                {{ trans("lang.customerlevel_name_help") }}
            </div>
        </div>
    </div>

<!-- Name Field -->
<div class="form-group row ">
  {!! Form::label('name', trans("lang.partystream_name"), ['class' => 'col-3 control-label text-right required']) !!}
  <div class="col-9">
    {!! Form::text('name', null,  ['class' => 'form-control','placeholder'=>  trans("lang.partystream_name_placeholder")]) !!}
    <div class="form-text text-muted">
      {{ trans("lang.partystream_name_help") }}
    </div>
  </div>
</div>

<!-- Description Field -->
<div class="form-group row ">
  {!! Form::label('description', trans("lang.partystream_description"), ['class' => 'col-3 control-label text-right required']) !!}
  <div class="col-9">
    {!! Form::textarea('description', null, ['class' => 'form-control','placeholder'=>
     trans("lang.partystream_description_placeholder")  ]) !!}
    <div class="form-text text-muted">{{ trans("lang.partystream_description_help") }}</div>
  </div>
</div>

<div class="form-group row ">
    {!! Form::label('active', trans("lang.partystream_active"),['class' => 'col-3 control-label text-right']) !!}
    <div class="checkbox icheck">
        <label class="col-9 ml-2 form-check-inline">
            {!! Form::hidden('active', 0) !!}
            {!! Form::checkbox('active', 1, 1) !!}
        </label>
    </div>
</div>
        
</div>
<div style="flex: 50%;max-width: 50%;padding: 0 4px;" class="column">

<!-- Image Field -->

</div>
@if($customFields)
<div class="clearfix"></div>
<div class="col-12 custom-field-container">
  <h5 class="col-12 pb-4">{!! trans('lang.custom_field_plural') !!}</h5>
  {!! $customFields !!}
</div>
@endif
<!-- Submit Field -->
<div class="form-group col-12 text-right">
  <button type="submit" class="btn btn-{{setting('theme_color')}}" ><i class="fa fa-save"></i> {{trans('lang.save')}} {{trans('lang.subcategory')}}</button>
  <a href="{!! route('partystream.index') !!}" class="btn btn-default"><i class="fa fa-undo"></i> {{trans('lang.cancel')}}</a>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
 <script> 
$(".customerlevel_id").change(function(){

  var customerlevel_id = $(this).val();
  var others = $('#customerlevel_count').val();
  
  if(others==customerlevel_id)
  {
    $('.customerlevel_name').show();
  }
  else
  {
    $('.customerlevel_name').hide();
  }
});
</script>